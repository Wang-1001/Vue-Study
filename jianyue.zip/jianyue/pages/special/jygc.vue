<template>
	<view><text>这里是简友广场</text></view>
</template>

<script>
</script>

<style>
</style>
