<template>
	<view><text>这里是投诉建议</text></view>
</template>

<script>
</script>

<style>
</style>
