<template>
	<view><text>这里是热门专题</text></view>
</template>

<script>
</script>

<style>
</style>
