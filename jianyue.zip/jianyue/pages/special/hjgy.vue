<template>
	<view><text>这里是互加公益</text></view>
</template>

<script>
</script>

<style>
</style>
