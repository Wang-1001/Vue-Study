<template>
	<view><text>这里是贝市场</text></view>
</template>

<script>
</script>

<style>
</style>
