<template>
	<view>
		<text>啊hahahahaha'</text>
	</view>
</template>

<script>
</script>

<style>
</style>
